// Initialize Lucide icons
lucide.createIcons();

document.addEventListener('DOMContentLoaded', () => {
    // Gender toggle
    const genderOptions = document.querySelectorAll('.gender-option');
    genderOptions.forEach(option => {
        option.addEventListener('click', () => {
            genderOptions.forEach(opt => opt.classList.remove('active'));
            option.classList.add('active');
        });
    });

    // Modules toggle
    const modules = document.querySelectorAll('.module-card');
    modules.forEach(module => {
        module.addEventListener('click', () => {
            modules.forEach(m => {
                m.classList.remove('active');
                const icon = m.querySelector('.check-icon');
                if (icon) icon.remove();
            });
            module.classList.add('active');
            const checkIcon = document.createElement('i');
            checkIcon.setAttribute('data-lucide', 'check-circle-2');
            checkIcon.classList.add('check-icon');
            module.appendChild(checkIcon);
            lucide.createIcons();
        });
    });

    // Tabs toggle
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
        });
    });

    // === Upload & Analysis Logic ===
    const uploadArea = document.getElementById('upload-area');
    const fileUpload = document.getElementById('file-upload');
    const uploadBox = document.getElementById('upload-box');
    const uploadedPreview = document.getElementById('uploaded-preview');
    const fileInfo = document.getElementById('file-info');
    const fileName = document.getElementById('file-name');
    const fileSize = document.getElementById('file-size');
    const analyzeBtn = document.getElementById('analyze-btn');

    // Result elements
    const analysisContent = document.getElementById('analysis-content');
    const analysisPlaceholder = document.getElementById('analysis-placeholder');
    const resultImage = document.getElementById('result-image');
    const resultAlert = document.getElementById('result-alert');
    const resultIcon = document.getElementById('result-icon');
    const resultStatus = document.getElementById('result-status');
    const resultRisk = document.getElementById('result-risk');
    const resultConfidence = document.getElementById('result-confidence');
    const resultConfidenceBar = document.getElementById('result-confidence-bar');
    const resultRecommendation = document.getElementById('result-recommendation');
    const localizationRow = document.getElementById('localization-row');
    const heatmapOverlay = document.getElementById('heatmap-overlay');

    // Маппинг класса на русское название
    const diseaseNames = {
        'No Finding':     'Норма',
        'Normal':         'Норма',
        'Pneumonia':      'Пневмония',
        'Cardiomegaly':   'Кардиомегалия',
        'Nodule':         'Узелок (возможное новообразование)',
    };

    // Маппинг класса на рекомендацию
    const recommendations = {
        'No Finding':   'Снимок в пределах нормы. Дополнительных действий не требуется.',
        'Normal':       'Снимок в пределах нормы. Дополнительных действий не требуется.',
        'Pneumonia':    'Обнаружены признаки пневмонии. Рекомендуется срочная консультация пульмонолога.',
        'Cardiomegaly': 'Обнаружены признаки кардиомегалии. Рекомендуется консультация кардиолога.',
        'Nodule':       'Обнаружен узелок в лёгких. Рекомендуется КТ и консультация онколога для исключения злокачественного образования.',
    };

    let selectedFile = null;

    if (uploadArea) {
        uploadArea.addEventListener('click', () => fileUpload.click());
    }

    if (fileUpload) {
        fileUpload.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                selectedFile = file;
                fileName.textContent = file.name;
                fileSize.textContent = (file.size / (1024 * 1024)).toFixed(2) + ' МБ';
                fileInfo.style.display = 'flex';

                const reader = new FileReader();
                reader.onload = (e) => {
                    uploadedPreview.src = e.target.result;
                    uploadedPreview.style.display = 'block';
                    uploadBox.style.display = 'none';
                };
                reader.readAsDataURL(file);

                analysisContent.style.display = 'none';
                analysisPlaceholder.style.display = 'block';
            }
        });
    }

    if (analyzeBtn) {
        analyzeBtn.addEventListener('click', async () => {
            if (!selectedFile) {
                alert("Пожалуйста, загрузите рентгенограмму перед началом анализа.");
                return;
            }

            const originalHtml = analyzeBtn.innerHTML;
            analyzeBtn.innerHTML = '<i data-lucide="loader-2" class="btn-icon"></i> Анализ...';
            analyzeBtn.disabled = true;
            lucide.createIcons();

            try {
                const formData = new FormData();
                formData.append('file', selectedFile);

                const response = await fetch('/predict', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (!response.ok) throw new Error(data.error || 'Ошибка при анализе');

                // Показываем результаты
                analysisPlaceholder.style.display = 'none';
                analysisContent.style.display = 'block';
                resultImage.src = uploadedPreview.src;

                const confVal = Math.round(data.confidence || 0);
                resultConfidence.textContent = confVal + '%';
                resultConfidenceBar.style.width = confVal + '%';

                const diseaseName = diseaseNames[data.disease] || data.disease;
                const recommendation = recommendations[data.disease] || 'Рекомендуется консультация врача.';

                if (data.prediction === 'Normal') {
                    resultAlert.className = 'alert';
                    resultAlert.style.backgroundColor = '#ecfdf5';
                    resultAlert.style.borderColor = '#10b981';
                    resultIcon.setAttribute('data-lucide', 'check-circle-2');
                    resultStatus.textContent = 'Патологий не выявлено — ' + diseaseName;
                    resultStatus.style.color = '#047857';
                    localizationRow.style.display = 'none';
                    resultRisk.textContent = 'низкий';
                    resultRisk.className = 'text-green';
                    heatmapOverlay.style.display = 'none';
                } else {
                    resultAlert.className = 'alert alert-danger';
                    resultAlert.style.backgroundColor = '';
                    resultAlert.style.borderColor = '';
                    resultIcon.setAttribute('data-lucide', 'alert-circle');
                    resultStatus.textContent = 'Обнаружено: ' + diseaseName;
                    resultStatus.style.color = '';
                    localizationRow.style.display = 'flex';
                    resultRisk.textContent = confVal > 80 ? 'высокий' : 'средний';
                    resultRisk.className = 'text-danger';

                    // Реальная GradCAM тепловая карта
                    if (data.heatmap) {
                        heatmapOverlay.style.display = 'block';
                        heatmapOverlay.style.backgroundImage = `url(${data.heatmap})`;
                        heatmapOverlay.style.backgroundSize = 'cover';
                        heatmapOverlay.style.opacity = '0.6';
                    }
                }

                resultRecommendation.textContent = recommendation;

                // Обновляем вероятности по вкладкам если есть
                if (data.all_probabilities) {
                    console.log('Вероятности по классам:', data.all_probabilities);
                }

                lucide.createIcons();

            } catch (error) {
                alert('Ошибка сервера: ' + error.message);
            } finally {
                analyzeBtn.innerHTML = originalHtml;
                analyzeBtn.disabled = false;
                lucide.createIcons();
            }
        });
    }
});