import os
import io
import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image
import numpy as np
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from contextlib import asynccontextmanager

# ==========================================
# Настройки
# ==========================================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Если обучил на 4 классах — меняй здесь
CLASS_NAMES = ['Normal', 'Pathology']# ImageFolder сортирует по алфавиту!
# CLASS_NAMES = ['Cardiomegaly', 'No Finding', 'Nodule', 'Pneumonia']  # ImageFolder сортирует по алфавиту!

# ==========================================
# Модель
# ==========================================
def get_model(num_classes):
    model = models.densenet121(weights=None)
    for param in model.features.parameters():
        param.requires_grad = False
    model.classifier = nn.Linear(model.classifier.in_features, num_classes)
    return model.to(device)

# ==========================================
# Трансформации
# ==========================================
transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])

# ==========================================
# GradCAM
# ==========================================
class GradCAM:
    def __init__(self, model):
        self.model = model
        self.gradients = None
        self.activations = None
        self.hook_layers()

    def hook_layers(self):
        def forward_hook(module, input, output):
            self.activations = output.detach()

        def backward_hook(module, grad_input, grad_output):
            self.gradients = grad_output[0].detach()

        # Последний denseblock DenseNet121
        target_layer = self.model.features.denseblock4
        target_layer.register_forward_hook(forward_hook)
        target_layer.register_full_backward_hook(backward_hook)

    def generate(self, image_tensor, class_idx):
        self.model.eval()
        image_tensor = image_tensor.requires_grad_(True)
        output = self.model(image_tensor)

        self.model.zero_grad()
        output[0, class_idx].backward()

        weights = self.gradients.mean(dim=[2, 3], keepdim=True)
        cam = (weights * self.activations).sum(dim=1, keepdim=True)
        cam = torch.relu(cam)
        cam = cam.squeeze().cpu().numpy()
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam

def cam_to_heatmap_base64(cam, size=(224, 224)):
    import base64
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from io import BytesIO

    cam_resized = np.array(Image.fromarray((cam * 255).astype(np.uint8)).resize(size))
    fig, ax = plt.subplots(figsize=(2.24, 2.24), dpi=100)
    ax.imshow(cam_resized, cmap='jet', alpha=0.6)
    ax.axis('off')
    buf = BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', pad_inches=0, transparent=True)
    plt.close()
    buf.seek(0)
    return "data:image/png;base64," + base64.b64encode(buf.read()).decode()

# ==========================================
# Предсказание
# ==========================================
def predict(image_bytes, model, gradcam):
    image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
    image_tensor = transform(image).unsqueeze(0).to(device)

    model.eval()
    with torch.no_grad():
        outputs = model(image_tensor)
        probabilities = torch.nn.functional.softmax(outputs, dim=1)[0]
        predicted_idx = probabilities.argmax().item()

    predicted_class = CLASS_NAMES[predicted_idx]
    confidence = probabilities[predicted_idx].item() * 100

    # Все вероятности по классам
    all_probs = {CLASS_NAMES[i]: round(probabilities[i].item() * 100, 1) for i in range(len(CLASS_NAMES))}

    # GradCAM
    image_tensor_grad = transform(image).unsqueeze(0).to(device)
    cam = gradcam.generate(image_tensor_grad, predicted_idx)
    heatmap_b64 = cam_to_heatmap_base64(cam)

    return predicted_class, confidence, all_probs, heatmap_b64

# ==========================================
# FastAPI
# ==========================================
global_model = None
global_gradcam = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    global global_model, global_gradcam
    global_model = get_model(num_classes=len(CLASS_NAMES))

    weights_path = "xray_model_best.pth"
    if not os.path.exists(weights_path):
        weights_path = "xray_model_weights.pth"

    if os.path.exists(weights_path):
        global_model.load_state_dict(torch.load(weights_path, map_location=device, weights_only=True))
        print(f"✅ Модель загружена из {weights_path}")
        print(f"✅ Классы: {CLASS_NAMES}")
    else:
        print("⚠️ Веса не найдены!")

    global_gradcam = GradCAM(global_model)
    yield
    global_model = None

app = FastAPI(title="NurTahlil AI", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def read_index():
    return FileResponse("index.html")

@app.post("/predict")
async def predict_endpoint(file: UploadFile = File(...)):
    if global_model is None:
        return JSONResponse(status_code=500, content={"error": "Модель не загружена"})

    image_bytes = await file.read()
    pred_class, conf, all_probs, heatmap = predict(image_bytes, global_model, global_gradcam)

    # Определяем это норма или патология для фронтенда
    is_normal = pred_class in ['No Finding', 'Normal']

    return {
        "prediction": "Normal" if is_normal else "Pathology",
        "disease": pred_class,          # конкретный класс
        "confidence": round(conf, 1),
        "all_probabilities": all_probs, # все классы с вероятностями
        "heatmap": heatmap              # base64 тепловая карта
    }

@app.get("/{filename}")
async def get_static(filename: str):
    if os.path.exists(filename) and os.path.isfile(filename):
        return FileResponse(filename)
    return JSONResponse(status_code=404, content={"message": "File not found"})

if __name__ == "__main__":
    print("🚀 Запуск NurTahlil AI сервера...")
    uvicorn.run("main5:app", host="127.0.0.1", port=8000, reload=True)